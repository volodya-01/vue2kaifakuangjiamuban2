<template>
    <div class="box">
      RunningState
    </div>
</template>
<script>
export default {
    name:"RunningState",

}
</script>
<style scoped>

</style>

