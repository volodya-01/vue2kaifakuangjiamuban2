<template>
    <div>AccuracyFollowing</div>
</template>
<script>
export default {
    name:"AccuracyFollowing"
}
</script>

