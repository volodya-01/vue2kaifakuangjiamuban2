<template>
    <div>
        SupplyPathNew
    </div>
</template>
<script>
export default {
    name:"SupplyPathNew"
}
</script>

