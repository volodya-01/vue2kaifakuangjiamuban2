<template>
    <div>
        BurstPipe
    </div>
</template>
<script>
export default {
    name:"BurstPipe"
}
</script>

