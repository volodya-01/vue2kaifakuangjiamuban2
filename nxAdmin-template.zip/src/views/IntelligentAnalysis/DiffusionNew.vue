<template>
    <div>DiffusionNew</div>
</template>
<script>
export default {
    name:"DiffusionNew"
}
</script>

