<template>
    <div>
      DailyScheduling
    </div>
</template>
<script>
export default {
    name:"DailyScheduling",

}
</script>

