<template>
    <div>PlanningScheduling</div>
</template>
<script>
export default {
    name:"PlanningScheduling"
}
</script>
