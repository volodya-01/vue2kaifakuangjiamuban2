<template>
    <div>EmergencyDispatch</div>
</template>
<script>
export default {
    name:"EmergencyDispatch"
}
</script>
