<template>
    <div>BudgetManagement</div>
</template>
<script>
export default {
    name:"BudgetManagement"
}
</script>
